@extends('layouts.master')


@section('title')
   Dashboard || Admin
@endsection



@section('content')

<div class="row">
        <div class="col-md-12">
          <div class="card">
            <div class="row justify-content-center mb-3 mt-3" >
              <div class="col-10"style="font-size:60px; text-align:center;"><b>
                  ON ROAD VEHICLE REPAIR SERVICE</b>
              </div>                   
              </div>    
            <div class="card-header">
              <h4 class="card-title"> Welcome To The  Quality, Functionality And Guaranteed Web System</h4>
            </div>
            <div class="card-body">
                                   
              <div class="row justify-content-center ">
                <div class="col-md-12 ">
                    <img src="11.jpg" alt="" width="100%" height="90%" >  
                  </div>  
                           
             </div>  
                             
            </div>
          </div>
        </div>
      </div>  

@endsection


@section('scripts')

@endsection

    
 