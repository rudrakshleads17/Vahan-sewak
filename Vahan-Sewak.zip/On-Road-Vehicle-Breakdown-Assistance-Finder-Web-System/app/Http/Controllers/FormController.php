<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Formcontroller;
class FormController extends Controller
{
    public function store(request $request){
        dd($request);
    }
}
?>
