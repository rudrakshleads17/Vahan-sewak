<?php $__env->startSection('title'); ?>
   
<?php $__env->stopSection(); ?>
        


<?php $__env->startSection('content'); ?>

<div class="row bg-dark">
        <div class="col-md-12">
          <div class="card bg-dark text-white">
            <div class="card-header">
              <div style="float:left;"><h4 class="card-title">Requested Mechanics </h4></div>
              
            </div>
            <div class="card-body ">
              
              <div class="table-responsive">
               
                <table class="table text-center">
                  <thead class="text-primary">
                      
                    <th>
                     MECHANIC NAME
                    </th>
                   
                    <th>
                        MECHANIC EMAIL
                    </th>
                    <th>
                      REQUESTED TIME
                   </th>
                    
                    <th>
                     REQUESTED
                     </th>
                    <th>
                    ACTION
                
                    </th>
                  </thead>
                  <tbody class="text-white">
                      <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <tr>
                      
                      <td>
                     <?php echo e($row->name); ?>

                      </td>
                     
                      <td>
                          <?php echo e($row->mechanic_email); ?>

                       </td> 
                       <td>
                        <?php echo e($row->updated_at); ?>

                     </td> 
                      
                      <td>
                        <?php if( $row->Is_requested): ?>
                       <button class="btn btn-success">Requested</button>
                      <?php else: ?>
                      <button class="btn btn-warning">Not Requested</button>
                     <?php endif; ?>
                     </td>
                     <td>
                       <?php if( $row->Is_requested): ?>
                     <a href="/markasnotrequested/<?php echo e($row->id); ?>" class="btn btn-danger">Mark As Not Requested </a>
                     <?php else: ?>
                     <a href="/markasrequested/<?php echo e($row->id); ?>" class="btn btn-primary">Mark As Requested </a>
                      <?php endif; ?>
                   </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>                      
                                        
                       
                </table>
                
               
              </div>
            </div>
          </div>
        </div>
      </div>  

      

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp741\htdocs\on-demand8\On-Road-Vehicle-Breakdown-Assistance-Finder-Web-System\resources\views/customer/requestlist.blade.php ENDPATH**/ ?>