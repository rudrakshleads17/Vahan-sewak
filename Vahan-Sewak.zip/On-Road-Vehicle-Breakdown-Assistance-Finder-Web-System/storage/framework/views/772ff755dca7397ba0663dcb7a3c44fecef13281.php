<?php $__env->startSection('title'); ?>
   user profile
<?php $__env->stopSection(); ?>
        


<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card bg-dark text-white"  >
                <img src="/uploads/avatars/<?php echo e(auth::user()->avatar); ?> " alt="" style="width:200px; height:200px; float:left;border-radius:50%;margin:20px 40px 0px;" >
               <h2 class="text-warning mtn"  style="margin: 50px 0 0 0;padding: 0 0 0 0;"><?php echo e(auth::user()->name); ?>'s profile </h2>

                <div class="card-body" style="font-size:16px;">
                    <form method="POST" action="/adminupdate" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        
                        <label for="" class="text-white">Update Profile Image</label>
                        <input type="file" name="avatar" >
                        
                        <?php if(session('success')): ?>
                        <div class="alert justify-content-center" role="alt" style="color:red;">
                            <?php echo e(session('success')); ?>

                        </div>
                        <?php endif; ?> 
                        <div class="pt-xl-5">
                        <div class="form-group row ml-2 mt-5">
                        <label for="name"  class="col-md-4 col-form-label text-white"><?php echo e(__('NAME')); ?></label>

                            <div class="col-md-7">
                                <input id="name" value="<?php echo e(Auth::user()->name); ?>" type="text" class="text-black bg-white form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
  
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group row ml-2">
                                <label for="location" class="col-md-4 col-form-label  text-white"><?php echo e(__('LOCATION')); ?></label>
    
                                <div class="col-md-7">
                                    <input id="location" value="<?php echo e(Auth::user()->location); ?>" type="text" class="text-black bg-white form-control <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="location" value="<?php echo e(old('location')); ?>" required autocomplete="location" autofocus>
    
                                    <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                        <div class="form-group row ml-2">
                            <label for="email" class="col-md-4 col-form-label  text-white"><?php echo e(__('EMAIL ADDRESS')); ?></label>

                            <div class="col-md-7">
                                <input id="email" value="<?php echo e(Auth::user()->email); ?>" type="email" class="text-black bg-white form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                       
                         
                        <div class="form-group row ml-2">
                                <label for="gender" class="col-md-4 col-form-label  text-white"><?php echo e(__('GENDER')); ?></label>
    
                                <div class="col-md-7">
                                <select value="<?php echo e(Auth::user()->gender); ?>" type="text" class="text-black bg-white form-control <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="gender" value="<?php echo e(old('gender')); ?>" required autocomplete="gender">
                                    <option value="<?php echo e(Auth::user()->gender); ?>" ><?php echo e(Auth::user()->gender); ?></option>
                                    <option value="Male" >Male</option>
                                  <option value="Female" >Female</option>
                                </select>                                  
                                </div>
                            </div>
                            <div class="form-group row ml-2">
                                <label for="" class="col-md-4 col-form-label  text-white"><?php echo e(__('REGESTRATION DATE')); ?></label>
    
                                <div class="col-md-7">
                                    <input id="" value="<?php echo e(Auth::user()->created_at); ?>" type="" class="text-black bg-white form-control">
    
                                   
                                </div>
                            </div>
                           
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('UPDATE')); ?>

                                </button>
                                <a href="/profile1" class="btn btn-danger">CANCEL</a>
                            </div>
                        </div>
                        </div>    
                        
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

    
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp741\htdocs\on-demand8\On-Road-Vehicle-Breakdown-Assistance-Finder-Web-System\resources\views/admin/profile.blade.php ENDPATH**/ ?>