<?php $__env->startSection('title'); ?>
   Registered Mechanics
<?php $__env->stopSection(); ?>
        


<?php $__env->startSection('content'); ?>

<div class="row bg-dark">
        <div class="col-md-12">
          <div class="card bg-dark text-white">
            <div class="card-header">
              <div style="float:left;"><h4 class="card-title">Registered Mechanics </h4></div>
              <div class="col-md-6  " style="float:right;">
                <form action="/search" method="get" role="search">
                  <?php echo e(csrf_field()); ?>

                  
                  <div class="input-group" >
                   <div style="float:left ;" class="col-md-8 mt-2"> <input type="search" class="form-control" name="search" placeholder="choose your location......"></div>
                    <span class="input-group-prepend " style="float:right;" >
                      <button type="submit" class="btn btn-primary ">SEARCH</button>
                    </span>
                   </div>
                  
                  </div>
                  <?php if(session('success')): ?>
                  <div class="alert " role="alert" style="color:red; float:left">
                      <?php echo e(session('success')); ?>

                      
                      <?php endif; ?>
                </form>
              </div>     
             
         
            </div>
            <div class="card-body ">
              
              <div class="table-responsive">
               
                <table class="table text-center">
                  <thead class="text-primary">
                      
                    <th>
                        Name
                    </th>
                    <th>
                      Location
                    </th>
                    <th>
                      Email
                    </th>
                    <th>
                   Service Type
                    </th>
                    <th>
                     Phone
                    </th>
                    <th>
                      Gender 
                     </th>
                     <th>
                      REQUESTED
                      </th>
                     <th>
                     ACTION
                 
                     </th>
                    
                  </thead>
                  <tbody class="text-white">
                      <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                     
                      <td>
                     <?php echo e($row->name); ?>

                      </td>
                      <td>
                        <?php echo e($row->location); ?>

                         </td>
                      <td>
                          <?php echo e($row->email); ?>

                       </td>
                      <td>
                       <?php echo e($row->servicetype); ?>

                      </td>
                       <td>
                        <?php echo e($row->phone); ?>

                       </td>
                       <td>
                        <?php echo e($row->gender); ?>

                       </td>
                      
                       <td>
                        <?php if($row->Is_requested ): ?>
                       <button class="btn btn-success">Requested</button>
                      <?php else: ?>
                      <button class="btn btn-warning">Not Requested</button>
                     <?php endif; ?>
                     </td>
                     <td>
                       <?php if($row->Is_requested): ?>
                     <a href="/markasnotrequested/<?php echo e($row->id); ?>" class="btn btn-danger">Mark As Not Requested </a>
                     <?php else: ?>
                     <a href="/markasrequested/<?php echo e($row->id); ?>" class="btn btn-primary">Mark As Requested </a>
                      <?php endif; ?>
                   </td>
                       </div>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>  

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

    
<?php echo $__env->make('layouts.master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp741\htdocs\on-demand8\On-Road-Vehicle-Breakdown-Assistance-Finder-Web-System\resources\views/customer/list.blade.php ENDPATH**/ ?>